#!/usr/bin/env python3
"""Apply/roll back the supplied TC100 patch to an OFFLINE SD, from a computer.
Default is read-only verification. No network, firmware flash or camera commands.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import sys
import tempfile

PACKAGE = Path(__file__).resolve().parent

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def checked_file(root, name):
    rel = PurePosixPath(name)
    if not name or rel.is_absolute() or any(p in ('..', '.') for p in rel.parts):
        raise ValueError('Chemin interdit: ' + name)
    if not (name in ('VERSION', 'autorun.sh', 'config/boot.conf.dist') or
            rel.parts[0] in ('scripts', 'controlscripts', 'www')):
        raise ValueError('Fichier hors périmètre: ' + name)
    path = root
    for part in rel.parts:
        path = path / part
        if path.is_symlink():
            raise ValueError('Lien symbolique refusé: ' + str(path))
    if not path.is_file():
        raise ValueError('Fichier absent ou non régulier: ' + str(path))
    return path

def load_manifest(path):
    obj = json.loads(path.read_text())
    files = obj['files']
    if not files or len({f['path'] for f in files}) != len(files):
        raise ValueError('Manifeste vide ou dupliqué')
    return obj

def replace(src, dst, mode):
    fd, tmp = tempfile.mkstemp(prefix='.tc100-stage-', dir=dst.parent)
    try:
        with os.fdopen(fd, 'wb') as output, src.open('rb') as input_file:
            shutil.copyfileobj(input_file, output)
            output.flush()
            os.fsync(output.fileno())
        os.chmod(tmp, mode)
        os.replace(tmp, dst)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)

def sync_card():
    if hasattr(os, 'sync'):
        os.sync()

def verify(root, manifest, source, expected):
    checked = []
    for row in manifest['files']:
        name = row['path']
        target = checked_file(root, name)
        payload = checked_file(source, name)
        if digest(payload) != row[expected]:
            raise ValueError('Empreinte du paquet/de la sauvegarde invalide: ' + name)
        checked.append((row, target, payload))
    return checked

def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sd', required=True, type=Path, help='Racine de la carte montée, caméra éteinte')
    action = parser.add_mutually_exclusive_group()
    action.add_argument('--apply', action='store_true', help='Appliquer après vérification complète')
    action.add_argument('--rollback', type=Path, help='Restaurer une sauvegarde créée par cet outil')
    parser.add_argument('--backup', type=Path, help='Nouveau dossier de sauvegarde SUR L’ORDINATEUR, requis avec --apply')
    args = parser.parse_args(argv)
    root = args.sd.resolve(strict=True)
    if root == Path('/') or not (root / 'config').is_dir() or not (root / 'bin').is_dir():
        raise ValueError('La cible ne ressemble pas à la racine de la carte TC100')
    if args.rollback:
        backup = args.rollback.resolve(strict=True)
        manifest = load_manifest(backup / 'manifest.json')
        checked = verify(root, manifest, backup / 'original', 'before')
        for row, target, payload in checked:
            if digest(target) not in (row['before'], row['after']):
                raise ValueError('Modification ultérieure à préserver; restauration automatique refusée: ' + row['path'])
        for row, target, payload in checked:
            replace(payload, target, row['mode'])
        sync_card()
        print('Retour arrière terminé; éjectez proprement la carte.')
        return

    manifest = load_manifest(PACKAGE / 'manifest.json')
    checked = verify(root, manifest, PACKAGE / 'apres', 'after')
    for row, target, payload in checked:
        if digest(target) != row['before']:
            raise ValueError('Version différente ou fichier personnalisé; aucune application: ' + row['path'])
    print(str(len(checked)) + ' fichiers conformes à la base ' + manifest['base_commit'][:12] + '.')
    if not args.apply:
        print('Vérification seule: aucun fichier modifié. Utilisez --apply --backup DOSSIER pour appliquer.')
        return
    if not args.backup:
        raise ValueError('--backup est obligatoire avec --apply')
    backup = args.backup.resolve()
    if backup == root or root in backup.parents:
        raise ValueError('La sauvegarde doit être conservée hors de la carte')
    backup.mkdir(mode=0o700, parents=False, exist_ok=False)
    # Complete and verify every original BEFORE touching the card.
    for row, target, payload in checked:
        original = backup / 'original' / row['path']
        original.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(target, original)
        if digest(original) != row['before']:
            raise ValueError('Sauvegarde non conforme: ' + row['path'])
        row['mode'] = stat.S_IMODE(target.stat().st_mode)
    with (backup / 'manifest.json').open('w') as output:
        json.dump(manifest, output, indent=2)
        output.flush()
        os.fsync(output.fileno())
    sync_card()
    print('Sauvegarde vérifiée: ' + str(backup), flush=True)
    try:
        for row, target, payload in checked:
            replace(payload, target, row['mode'])
            if digest(target) != row['after']:
                raise OSError('Vérification après écriture échouée: ' + row['path'])
        sync_card()
    except Exception:
        # Best effort recovery after an I/O failure; backup remains on the host.
        for row, target, payload in checked:
            replace(backup / 'original' / row['path'], target, row['mode'])
        sync_card()
        raise
    print('Essai installé. Éjectez proprement la carte avant de rallumer la caméra.')

if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError) as error:
        print('ARRÊT: ' + str(error), file=sys.stderr)
        sys.exit(1)
