"""Host-only application/rollback tests against a simulated SD card.
Run from the extracted trial package: python3 -m unittest test_essai_sd -v
"""
from pathlib import Path
import hashlib
import importlib.util
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

PACKAGE = Path(__file__).resolve().parent

class OfflineTrial(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='tc100-sd-test-')
        self.base = Path(self.temp.name)
        self.sd = self.base / 'SD'
        shutil.copytree(PACKAGE / 'avant', self.sd)
        (self.sd / 'bin').mkdir()
        (self.sd / 'config/mqtt.conf').write_text('PERSONAL_SETTING=preserve\n')
        self.original = self.snapshot()
        self.backup = self.base / 'backup'

    def tearDown(self):
        self.temp.cleanup()

    def snapshot(self):
        return {str(p.relative_to(self.sd)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in self.sd.rglob('*') if p.is_file()}

    def call(self, *args):
        return subprocess.run([sys.executable, str(PACKAGE / 'essai_sd.py'), '--sd', str(self.sd), *map(str,args)],
                              capture_output=True, timeout=15)

    def test_check_does_not_write(self):
        r = self.call()
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual(self.snapshot(), self.original)
        self.assertFalse(self.backup.exists())

    def test_apply_and_rollback_preserve_personal_config(self):
        r = self.call('--apply', '--backup', self.backup)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual((self.sd / 'VERSION').read_text().strip(), '1.8.3-rc1')
        self.assertEqual((self.sd / 'config/mqtt.conf').read_text(), 'PERSONAL_SETTING=preserve\n')
        r = self.call('--rollback', self.backup)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual(self.snapshot(), self.original)

    def test_customized_file_blocks_entire_apply(self):
        (self.sd / 'autorun.sh').write_text('# customized\n')
        customized = self.snapshot()
        r = self.call('--apply', '--backup', self.backup)
        self.assertNotEqual(r.returncode, 0)
        self.assertEqual(self.snapshot(), customized)
        self.assertFalse(self.backup.exists())

    def test_symlink_blocks_entire_apply(self):
        (self.sd / 'VERSION').unlink()
        (self.sd / 'VERSION').symlink_to(PACKAGE / 'avant/VERSION')
        r = self.call('--apply', '--backup', self.backup)
        self.assertNotEqual(r.returncode, 0)
        self.assertFalse(self.backup.exists())

    def test_rollback_preserves_changes_made_after_trial(self):
        self.assertEqual(self.call('--apply', '--backup', self.backup).returncode, 0)
        (self.sd / 'autorun.sh').write_text('# newer edit\n')
        customized = self.snapshot()
        r = self.call('--rollback', self.backup)
        self.assertNotEqual(r.returncode, 0)
        self.assertEqual(self.snapshot(), customized)

    def test_copy_failure_rolls_back_partial_apply(self):
        spec = importlib.util.spec_from_file_location('offline_trial', PACKAGE / 'essai_sd.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        original_replace = module.replace
        count = 0
        def fail_once(src, dst, mode):
            nonlocal count
            count += 1
            if count == 2:
                raise OSError('simulated write failure')
            original_replace(src, dst, mode)
        with patch.object(module, 'replace', fail_once):
            with self.assertRaisesRegex(OSError, 'simulated write failure'):
                module.main(['--sd', str(self.sd), '--apply', '--backup', str(self.backup)])
        self.assertEqual(self.snapshot(), self.original)
        self.assertTrue((self.backup / 'manifest.json').is_file())

if __name__ == '__main__':
    unittest.main()
